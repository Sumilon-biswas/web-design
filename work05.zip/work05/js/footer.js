const createFooter=()=>{
    let footer=document.querySelector('footer');
    footer.innerHTML='<div class="footer-content">\
             <img src="img/light-logo.png" alt="" class="logo">\
             <div class="footer-ul-container">\
                <ul class="category">\
                    <li class="category-tittle">Men</li>\
                    <li><a href="#" class="category-link">t-shrits</a></li>\
                    <li><a href="#" class="category-link">sweat T-shrits</a></li>\
                    <li><a href="#" class="category-link">shrits</a></li>\
                    <li><a href="#" class="category-link">trouser</a></li>\
                    <li><a href="#" class="category-link">shoes</a></li>\
                    <li><a href="#" class="category-link">casusal</a></li>\
                    <li><a href="#" class="category-link">formal</a></li>\
                    <li><a href="#" class="category-link">sports</a></li>\
                    <li><a href="#" class="category-link">formal</a></li>\
                    <li><a href="#" class="category-link">watch</a></li>\
                </ul>\
                <ul class="category">\
                    <li class="category-tittle">Women</li>\
                    <li><a href="#" class="category-link">t-shrits</a></li>\
                    <li><a href="#" class="category-link">sweat T-shrits</a></li>\
                    <li><a href="#" class="category-link">shrits</a></li>\
                    <li><a href="#" class="category-link">trouser</a></li>\
                    <li><a href="#" class="category-link">shoes</a></li>\
                    <li><a href="#" class="category-link">casusal</a></li>\
                    <li><a href="#" class="category-link">formal</a></li>\
                    <li><a href="#" class="category-link">sports</a></li>\
                    <li><a href="#" class="category-link">formal</a></li>\
                    <li><a href="#" class="category-link">watch</a></li>\
                </ul>\
             </div>\
          </div>\
          <p class="footer-tittle">About company</p>\
          <p class="info">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\
         <p class="info">supported Email ::sumilonbiswas@gmail.com</p>\
         <p class="info">phon No::01767681499</p>\
         <div class="footer-social-container">\
            <div>\
                <a href="#" class="social-link">trems & services</i></a>\
                <a href="#" class="social-link">privacy page</a>\
            </div>\
            <div>\
                <a href="#" class="social-link">Instagram<i class="fa fa-instagram"></i></a>\
                <a href="#" class="social-link">Facebook<i class="fa fa-facebook-square"></i></a>\
                <a href="#" class="social-link">Twitter<i class="fa fa-twitter"></i></i></a>\
            </div>\
         </div>\
         <div class="footer-credite">\
            <p>Clothing, Best appearls online store</p>\
         </div>\
    ';
}
createFooter();